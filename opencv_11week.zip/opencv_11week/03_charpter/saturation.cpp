int main()
{
	cv::Mat image = cv::imread("boldt.jpg");
	if (!image.data)
		return 0;

	cv::namedWindow("Original image");
	cv::imshow("Original image", image);

	// ת��HSV
	cv::Mat hsv;
	cv::cvtColor(image, hsv, CV_BGR2HSV);

	std::vector<cv::Mat> channels;
	cv::split(hsv, channels);
	// channels[0] is the Hue
	// channels[1] is the Saturation
	// channels[2] is the Value

	cv::namedWindow("Value");
	cv::imshow("Value", channels[2]);

	cv::namedWindow("Saturation");
	cv::imshow("Saturation", channels[1]);

	cv::namedWindow("Hue");
	cv::imshow("Hue", channels[0]);
	//����0��3��ͨ���Ѿ�չʾ���
	
	//��ʣ�µ�ָ���ĸ���
	cv::Mat newImage;
	cv::Mat tmp(channels[2].clone());

	//
	channels[2] = 255;
	// ���ºϲ�ͨ��
	cv::merge(channels, hsv);
	
	cv::cvtColor(hsv, newImage, CV_HSV2BGR);  //��Ҫ
	//ת��RGB��ʾ�ռ�

	cv::namedWindow("Fixed Value Image");
	cv::imshow("Fixed Value Image", newImage);

	// ���϶ȵ����ֵ��ʱ��
	channels[1] = 255;
	channels[2] = tmp;
	cv::merge(channels, hsv);
	cv::cvtColor(hsv, newImage, CV_HSV2BGR);


	cv::namedWindow("Fixed saturation");
	cv::imshow("Fixed saturation", newImage);

	// ��ɫ�뱥��ͬʱ�������ֵ��ʱ��
	channels[1] = 255;
	channels[2] = 255;
	cv::merge(channels, hsv);
	cv::cvtColor(hsv, newImage, CV_HSV2BGR);

	cv::namedWindow("Fixed saturation/value");
	cv::imshow("Fixed saturation/value", newImage);

	// �ϳɹ۲�
	//���϶�0-255��ɫ��0-180
	cv::Mat hs(128, 360, CV_8UC3);
	for (int h = 0; h < 360; h++) { //�ж�Ӧ��ɫ��
		for (int s = 0; s < 128; s++) { //�ж�Ӧ���Ͷ�
			hs.at<cv::Vec3b>(s, h)[0] = h / 2;     // ɫ��
			hs.at<cv::Vec3b>(s, h)[1] = 255 - s * 2; // ���Ͷ�
			hs.at<cv::Vec3b>(s, h)[2] = 255;     //����
		}
	}

	cv::cvtColor(hs, newImage, CV_HSV2BGR);

	cv::namedWindow("Hue/Saturation");
	cv::imshow("Hue/Saturation", newImage);

	//��ɫ���

	//����ֻ��ɫ�����Ͷ�������ɫ


	// ��
	image = cv::imread("girl.jpg");
	if (!image.data)
		return 0;

	// show original image
	cv::namedWindow("Original image");
	cv::imshow("Original image", image);

	// �Զ���ķ�ɫ��⺯��
	cv::Mat mask;
	detectHScolor(image,
		160, 10, // ɫ�� from 320 degrees to 20 degrees 
		25, 166, // ���Ͷ� from ~0.1 to 0.65
		mask); //����

	// show masked image
  //��ɫ��ͨ����ͼ
	cv::Mat detected(image.size(), CV_8UC3, cv::Scalar(0, 0, 0));

	image.copyTo(detected, mask);
	cv::imshow("Detection result", detected);

	// A test comparing luminance and brightness

	// create linear intensity image
	cv::Mat linear(100, 256, CV_8U);
	for (int i = 0; i < 256; i++) {

		linear.col(i) = i;
	}

	// create a Lab image
	linear.copyTo(channels[0]);
	cv::Mat constante(100, 256, CV_8U, cv::Scalar(128));
	constante.copyTo(channels[1]);
	constante.copyTo(channels[2]);
	cv::merge(channels, image);

	// convert back to BGR
	cv::Mat brightness;
	cv::cvtColor(image, brightness, CV_Lab2BGR);
	cv::split(brightness, channels);

	// create combined image
	cv::Mat combined(200, 256, CV_8U);
	cv::Mat half1(combined, cv::Rect(0, 0, 256, 100));
	linear.copyTo(half1);
	cv::Mat half2(combined, cv::Rect(0, 100, 256, 100));
	channels[0].copyTo(half2);

	cv::namedWindow("Luminance vs Brightness");
	cv::imshow("Luminance vs Brightness", combined);

	cv::waitKey();
}