﻿// 3-2.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

int main()
{
	cv::Mat image = cv::imread ("boldt.jpg");

	if (!image.data)
		return 0;
	
	//显示输入图像
	cv::namedWindow("oringal");
	cv::imshow("oringal", image);

	cv::Rect rectange(50, 25, 210, 180);

	cv::Mat result;
	cv::Mat bGmodel, fGmodel;

	cv::grabCut(
		image,
		result,
		rectange,
		bGmodel, fGmodel,
		5,
		cv::GC_INIT_WITH_RECT); //使用带边款
	//result 有四种可能的值
	//
     //cv::GC_BGD;
	// cv::GC_FGD;
	 //cv::GC_PR_BGD;
	// cv::GC_PR_FGD;

	cv::Mat foreground(image.size(), CV_8UC3, cv::Scalar(255, 255, 255));  //创建输出图像
	//显示画了矩形的图像
	cv::rectangle(image, rectange, cv::Scalar(255, 255, 255), 1);
	cv::namedWindow("Image with rectangle");
	cv::imshow("Image with rectangle", image);

	// display result
	cv::namedWindow("Foreground object");
	cv::imshow("Foreground object", foreground);

	cv::waitKey();
	return 0;

}

