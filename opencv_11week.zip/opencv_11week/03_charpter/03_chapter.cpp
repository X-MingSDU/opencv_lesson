﻿// 03_chapter.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>

#include "colordetector.h"
#include <vector>


//创建迭代器







; int main()
{
#pragma region 用策略模式比较颜色

	ColorDetector cdetect; //创建图像处理器

	cv::Mat image = cv::imread("boldt.jpg");
	if (image.empty()) return 0;
	cv::namedWindow("O_image");
	cv::imshow("O_image", image);

	//设置输入参数
	cdetect.setTargetColor(230, 190, 130); //BGR颜色

	cv::Mat result = cdetect.process(image);

	//显示结果
	cv::namedWindow("result");
	cv::imshow("result", result);
	cv::waitKey();
#pragma endregion

#pragma region 使用Lab色彩空间
	ColorDetector colordetector(230, 190, 130, 45, true);

	result = colordetector(image);

	cv::namedWindow("result_f");
	cv::imshow("result_f", result);
	cv::waitKey();
#pragma endregion

#pragma region   flood p111
	cv::floodFill(
		image,
		cv::Point(100, 50),
	    cv::Scalar(255, 255, 255),
	    (cv::Rect*) 0,
	    cv::Scalar(35, 35, 35),
	    cv::Scalar(35, 35, 35),
	    cv::FLOODFILL_FIXED_RANGE);

	cv::namedWindow("flood_fill_r");
	cv::imshow("flood_fill_r", image);
	cv::waitKey();

	//这里把天空画成白色，即使其他地方有颜色相近的地方，除非与天空相连否则也不会被识别出来
#pragma endregion
	return 0;
}

