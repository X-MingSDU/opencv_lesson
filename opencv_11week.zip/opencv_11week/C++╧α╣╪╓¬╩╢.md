## C++相关知识

### 一、C++中双冒号

- 表示域操作符

- >例：声明了一个类A，类A里面声明了一个成员函数 void click()，但没有在类的声明里边给出 click 的定义，那么在类外定义 click 时，就要写成 void A::click()，表示这个 click() 函数是类A的成员函数。

![](E:\1网课\2opencv\冒号.png)

-  2、直接用在全局函数前，表示是全局函数
  例：在VC中，你可以在调用API函数里，在API函数名前面加：：
-  3、表示引用成员函数及变量，作用域成员运算符 

```cpp
System::Math::Sqrt()//相当于System.Math.Sqrt()
```

#### 单冒号

#####  (1）表示机构内位域的定义（即该变量占几个bit空间）

typedef struct _XXX{

unsigned char a:4;

unsigned char c;

} ; XXX

（2）构造函数后面的冒号起分割作用，是**类给成员变量赋值的方**法，初始化列表，更适用于成员变量的常量const型。

struct _XXX{_XXX() : y(0xc0) {};

```cpp
Line::Line( double len): length(len)
{
    cout << "Object is being created, length = " << len << endl;
}
```



##### （3） public:和private:后面的冒号，表示后面定义的所有成员都是公有或私有的，直到下一个"public:”或"private:”出现为止。"private:"为默认处理。

##### （4）类名冒号后面的是用来定义类的继承。

class 派生类名 : 继承方式 基类名

{

派生类的成员

};

继承方式：public、private和protected，默认处理是public。

### 二、bool

- > 真假判断，只有真和假

```cpp
bool b;
b=(1>2);   //b为false
```

### 三、类和对象

#### 定义和引用

- 类的三个特性

- >封装、继承、多态
  >
  >类的访问限定符协助其完成封装 || public、private（protected）
  >
  >默认为private

- 注：类外不能访问类内
- ![](E:\1网课\2opencv\类1.png)

- 类的对象可以通过.来访问类的公有成员，类的对象指针可以通过->来访问

  ```cpp
  class person
  {
  public:
  	void Display()
  	{
  		cout << _name <<"-"<< _age << endl;
  	}
  public:
  	int _age;
  	char* _name;
  };
   
  int main()
  {
  	person p;
  	p._age = 18;
  	p._name = "peter";
  	p.Display();
   
  	person* ptr = &p;
  	ptr->_age = 20;
  	ptr->_name = "jack";
  	ptr->Display();
   
  	system("pause");
  	return 0;
  }
  ```

-  类外定义成员函数，需要使用::（作用域解析符）指明其属于哪个类 

```cpp
class person
{
public:
	void Display();   //声明
};
void person::Display()//类外定义
{
	//......
}
```

#### 构造函数和析构函数

- >  构造函数的名称与类的名称是完全相同的，并且不会返回任何类型，也不会返回 void。构造函数可用于为某些成员变量设置初始值。 

```cpp
class Line
{......
public:
 Line();
}
Line::Line(void)
{
    cout << "Object is being created" << endl;
}
```

- > 默认的构造函数没有任何参数，但如果需要，构造函数也可以带有参数。这样在创建对象时就会给对象赋初始值 

```cpp
class Line
{......
public:
  Line(double len); 
}
```

-  使用初始化列表来初始化字段： 

  ```cpp
  Line::Line( double len): length(len)
  {
      cout << "Object is being created, length = " << len << endl;
  }
  或者是
  假设有一个类 C，具有多个字段 X、Y、Z 等需要进行初始化，同理地，您可以使用上面的语法，只需要在不同的字段使用逗号进行分隔，如下所示：
  C::C( double a, double b, double c): X(a), Y(b), Z(c)
  {
    ....
  }    
  
  ```

- 类的**析构函数**是类的一种特殊的成员函数，它会在每次删除所创建的对象时执行。

析构函数的名称与类的名称是完全相同的，只是在前面加了个波浪号（~）作为前缀，它不会返回任何值，也不能带有任何参数。析构函数有助于在跳出程序（比如关闭文件、释放内存等）前释放资源。

```cpp
~Line(); 
......
Line::~Line(void)
{
    cout << "Object is being deleted" << endl;
}
//运行结束时会自动跳出
```

#### 静态与常量

- **静态成员**：类里面的静态成员以`static`指明，这一成员较为特殊，**一个`static`成员只有唯一的一份副本，而不像常规的非`static`成员那样在每个在每个对象中均有一份副本**，最重要的一是静态成员（可以是某属性也可以是某成员函数），**不再属于某一特定的对象，而是在整个类的作用域都起作用**，只要在类中声明静态成员变量，即使不定义对象，也可以为静态成员变量分配空间，进而可以使用静态成员变量。

  ```cpp
  class Test
  {
  static int temp;
  public:
  static int getData()
  {
  return temp;
  }
  };
  int Test::temp=3;
  int main()
  {
  cout <<Test::getData()<<endl;
  return 0;
  }
  ```

- 用`static`修饰

  静态成员必须在类外初始化，如例子中的`temp` 

  静态函数可以被类调用，写成`Test::getData()`这样的形式，普通的成员函数不可以被类直接调用；同样可以通过类来获取静态成员(形式如`Test::temp`)而不可通过某对象获取

- 常量

  ```cpp
  int get_day() const { return this->day;}
  ......
  int get_day() const { 
  return this->day++;    //错误：在const函数内企图修改成员值
  }
  ```

### 四、函数重载

- > 定义：函数重载是一种特殊情况，C++允许在**同一作用域中**声明几个类似的同名函数，这些**同名函数的形参列表（参数个数，类型，顺序）必须不同**，常用来处理实现功能类似数据类型不同的问题。
  >
  >     在C++中不仅函数可以重载，运算符也可以重载。例如： 运算符<<,>>。既可以做移位运算符，也可以做输出，输入运算符。
  >

- 实现形式： **重载函数的参数个数，参数类型或参数顺序三者中必须有一个不同** 

- >  规则：名称相同，
  >
  > 参数列表(三个中至少一个不同)，
  >
  > 返回类型可以不同，
  >
  > 仅类型不同不能构成重载

```cpp
int Add(int a, int b)
{
	return a + b;
}
 
double Add(double a, double b)
{
	return a + b;
}
float Add(float a, float b)
{return a + b;}

```

```cpp
int max(int a, int b, int c);
int max(int a, int b);
```

### 五、仿函数

